#ifndef DISPLAY
#define DISPLAY
#include <icu_globals.h> 

#ifdef __cplusplus
extern "C" {
#endif

void updateDisplay();    
void update_data();

#ifdef __cplusplus
}
#endif


#endif

