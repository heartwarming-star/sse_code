#include <parts.h>

ws22_error_flags_t ws22_error_flags;
ws22_limit_flags_t ws22_limit_flags;
ws22_t ws22;
ICU_t ICU;
BMS_t BMS;
MPPT_t MPPT_array[3];
MPPT_Status_t MPPT_Status;
